"""
AI × Creative Production — Daily Pipeline
Collect → AI Agent Screen → Store (10/day, no repeats)
"""

import json, os, sys
from datetime import datetime, timedelta, timezone
from pathlib import Path

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from dotenv import load_dotenv

env_path = Path(__file__).parent.parent / "config" / ".env"
if env_path.exists(): load_dotenv(env_path)


def load_seen_ids(data_dir, window_days=30):
    seen = set()
    cutoff = datetime.now(timezone.utc) - timedelta(days=window_days)
    feeds_dir = data_dir / "feeds"
    if not feeds_dir.exists(): return seen
    for f in feeds_dir.glob("*.json"):
        try:
            fd = datetime.strptime(f.stem, "%Y-%m-%d").replace(tzinfo=timezone.utc)
            if fd < cutoff: continue
            with open(f) as fh:
                for p in json.load(fh).get("posts", []):
                    seen.add(p.get("source_id", ""))
        except Exception: continue
    return seen


def fetch_all_mock():
    now = datetime.now(timezone.utc)
    return [
        {"source":"x_twitter","source_id":"x_01","url":"#","author":{"name":"Jake Parker","username":"jakeparker","headline":"Filmmaker / Creative Tech"},"content":"I built a full short film pipeline with Runway + DaVinci Resolve + Claude for scripting — here's every step, from shot list to final color grade. Thread with timeline screenshots.","metrics":{"likes":4200,"retweets":980,"views":620000},"published_at":(now-timedelta(hours=6)).isoformat()},
        {"source":"x_twitter","source_id":"x_02","url":"#","author":{"name":"Maya 3D","username":"maya3d","headline":"3D Artist / Technical Artist"},"content":"ComfyUI + 3DGS: my workflow for turning phone scans into stylized game assets in under 10 minutes. Full node graph + downloadable workflow JSON inside.","metrics":{"likes":3100,"retweets":720,"views":410000},"published_at":(now-timedelta(hours=14)).isoformat()},
        {"source":"linkedin","source_id":"li_01","url":"#","author":{"name":"Anna Wei","username":"annawei","headline":"Senior Product Designer @ Figma"},"content":"How I use Figma AI + Claude to go from user research notes to interactive prototype in one afternoon. Complete step-by-step with real project screenshots.","metrics":{"likes":5600,"comments":380,"views":290000},"published_at":(now-timedelta(hours=10)).isoformat()},
        {"source":"x_twitter","source_id":"x_03","url":"#","author":{"name":"Motion Lab","username":"motionlab","headline":"Motion Designer / Art Director"},"content":"After Effects + Runway + Rive: building a hybrid motion system for product launches. Project file breakdown included. This is how studios will actually adopt AI.","metrics":{"likes":2800,"retweets":650,"views":380000},"published_at":(now-timedelta(days=1)).isoformat()},
        {"source":"linkedin","source_id":"li_02","url":"#","author":{"name":"Tom Rivera","username":"tomrivera","headline":"Freelance 3D Artist"},"content":"text-to-3D is finally usable: my honest assessment after testing every major tool on real client projects. What works, what doesn't, and the manual cleanup that's still required.","metrics":{"likes":4100,"comments":290,"views":220000},"published_at":(now-timedelta(days=1,hours=8)).isoformat()},
        {"source":"x_twitter","source_id":"x_04","url":"#","author":{"name":"VFX Breakdown","username":"vfxbreak","headline":"VFX Supervisor / AI Researcher"},"content":"Shot consistency in AI video: the techniques that actually work after 200+ generation tests. Systematic comparison across Kling, Sora, and Runway with quantified success rates.","metrics":{"likes":6700,"retweets":1800,"views":920000},"published_at":(now-timedelta(hours=20)).isoformat()},
        {"source":"github","source_id":"gh_01","url":"#","author":{"name":"tokenflow","username":"tokenflow"},"content":"design-tokens-ai: CLI tool that extracts design tokens from any Figma file and generates Tailwind config, CSS variables, or Swift/Kotlin theme files.","metrics":{"stars":1800,"forks":140},"topics":["figma","design-tokens","tailwind"],"published_at":(now-timedelta(days=2)).isoformat()},
        {"source":"linkedin","source_id":"li_03","url":"#","author":{"name":"Chris Park","username":"chrispark","headline":"Senior Motion Designer"},"content":"I replaced 60% of my After Effects work with Rive + AI — here's what I gained and what I lost. An honest account after 8 years of AE.","metrics":{"likes":3200,"comments":210,"views":170000},"published_at":(now-timedelta(days=2)).isoformat()},
        {"source":"github","source_id":"gh_02","url":"#","author":{"name":"splat-editor","username":"splateditor"},"content":"gaussian-splatting-editor: open-source web viewer and editor for 3DGS scenes with AI-powered inpainting. WebGPU-based, runs in-browser.","metrics":{"stars":2400,"forks":190},"topics":["3dgs","webgpu","editor"],"published_at":(now-timedelta(days=3)).isoformat()},
        {"source":"x_twitter","source_id":"x_05","url":"#","author":{"name":"Design Crits","username":"designcrits","headline":"Design Director"},"content":"The real cost of AI-generated UI: what breaks when you skip the design thinking. Specific examples where AI output looked polished but failed usability testing.","metrics":{"likes":3800,"retweets":890,"views":510000},"published_at":(now-timedelta(days=1,hours=12)).isoformat()},
    ]


def run_pipeline(use_mock=False):
    print(f"{'='*56}\n  AI × Creative Production — {datetime.now().strftime('%Y-%m-%d %H:%M')}\n{'='*56}")

    base = Path(__file__).parent.parent
    with open(base / "config" / "keywords.json") as f:
        config = json.load(f)

    seen = load_seen_ids(base / "data", config["agent"]["dedup_window_days"])
    print(f"  [{len(seen)} posts in dedup history]")

    print("\n  Collecting...")
    raw = fetch_all_mock() if use_mock else []
    fresh = [p for p in raw if p["source_id"] not in seen]
    print(f"  {len(fresh)} fresh / {len(raw)} total")

    if not fresh: print("  No fresh posts."); return None

    print("\n  Agent screening...")
    from ai_processor import process_posts_mock, process_posts
    top = process_posts_mock(fresh, config) if use_mock else process_posts(fresh, config)

    today = datetime.now(timezone.utc).strftime("%Y-%m-%d")
    out_dir = base / "data" / "feeds"
    out_dir.mkdir(parents=True, exist_ok=True)
    daily = {"date": today, "generated_at": datetime.now(timezone.utc).isoformat(), "posts": top}
    with open(out_dir / f"{today}.json", "w", encoding="utf-8") as f:
        json.dump(daily, f, ensure_ascii=False, indent=2)

    print(f"\n  Saved {len(top)} posts → {today}.json\n")
    for i, p in enumerate(top):
        ai = p.get("ai", {})
        src = {"x_twitter":"𝕏","linkedin":"in","github":"GH"}.get(p["source"],"?")
        print(f"  {i+1:2d}. [{src}] [{ai.get('domain','')}] {ai.get('title','')[:80]}")
        print(f"      workflow: {ai.get('workflow_stage','')} | tools: {', '.join(ai.get('tools_mentioned',[]))} | value: {ai.get('creative_workflow_value','?')}/10")

    return daily


if __name__ == "__main__":
    use_mock = "--live" not in sys.argv
    if use_mock: print("Mock mode (--live for real APIs)\n")
    run_pipeline(use_mock=use_mock)
